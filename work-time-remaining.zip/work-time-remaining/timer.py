"""
timer.py
---------
Core work-time calculation logic for the Work Time Remaining application.

This module is intentionally UI-agnostic: it knows nothing about
CustomTkinter and only deals with dates, times, and durations. Keeping
it independent of the UI layer makes the logic easy to reason about,
reuse, and test on its own.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from enum import Enum, auto

from utils import calculate_progress, format_duration


class WorkStatus(Enum):
    """Represents the current phase of the configured workday."""

    NOT_STARTED = auto()
    IN_PROGRESS = auto()
    COMPLETED = auto()


@dataclass
class WorkSnapshot:
    """An immutable snapshot of the workday state at a single moment in time."""

    status: WorkStatus
    now: dt.datetime
    start: dt.datetime
    end: dt.datetime
    worked_seconds: float
    remaining_seconds: float
    progress_percent: float

    @property
    def worked_label(self) -> str:
        """Human-readable worked-time string, e.g. '1h 45m'."""
        return format_duration(self.worked_seconds)

    @property
    def remaining_label(self) -> str:
        """Human-readable remaining-time string, e.g. '6h 15m'."""
        return format_duration(self.remaining_seconds)

    @property
    def progress_label(self) -> str:
        """Progress percentage formatted as a whole-number string, e.g. '22%'."""
        return f"{int(round(self.progress_percent))}%"

    @property
    def status_message(self) -> str:
        """A friendly, user-facing status message for the current phase."""
        if self.status is WorkStatus.NOT_STARTED:
            return "Work has not started."
        if self.status is WorkStatus.COMPLETED:
            return "🎉 Work Completed!"
        return "💼 Work in progress..."


class WorkTimer:
    """
    Computes work-time statistics (worked time, remaining time, progress)
    for a configured start/end time, relative to any given moment.
    """

    def __init__(self, start_time: dt.time, end_time: dt.time) -> None:
        self.start_time = start_time
        self.end_time = end_time

    def set_schedule(self, start_time: dt.time, end_time: dt.time) -> None:
        """Update the configured work start and end times."""
        self.start_time = start_time
        self.end_time = end_time

    @staticmethod
    def _combine_with_date(reference: dt.datetime, time_obj: dt.time) -> dt.datetime:
        """Combine `reference`'s date with a given `time_obj`."""
        return dt.datetime.combine(reference.date(), time_obj)

    def snapshot(self, now: dt.datetime | None = None) -> WorkSnapshot:
        """
        Compute a `WorkSnapshot` for the given moment (defaults to `datetime.now()`).

        Handles three phases:
          * NOT_STARTED -- before the configured start time.
          * IN_PROGRESS -- between the start and end time.
          * COMPLETED   -- at or after the configured end time.

        Overnight schedules (where the end time is numerically earlier
        than the start time, e.g. a night shift from 09:00 PM to 05:00 AM)
        are supported by rolling the end datetime over to the next day.
        """
        now = now or dt.datetime.now()
        start_dt = self._combine_with_date(now, self.start_time)
        end_dt = self._combine_with_date(now, self.end_time)

        # Support overnight shifts: if the end time lands on/before the
        # start time on the same calendar day, treat it as the next day.
        if end_dt <= start_dt:
            end_dt += dt.timedelta(days=1)

        if now < start_dt:
            status = WorkStatus.NOT_STARTED
            worked_seconds = 0.0
            remaining_seconds = (end_dt - start_dt).total_seconds()
            progress = 0.0
        elif now >= end_dt:
            status = WorkStatus.COMPLETED
            worked_seconds = (end_dt - start_dt).total_seconds()
            remaining_seconds = 0.0
            progress = 100.0
        else:
            status = WorkStatus.IN_PROGRESS
            worked_seconds = (now - start_dt).total_seconds()
            remaining_seconds = (end_dt - now).total_seconds()
            progress = calculate_progress(now, start_dt, end_dt)

        return WorkSnapshot(
            status=status,
            now=now,
            start=start_dt,
            end=end_dt,
            worked_seconds=worked_seconds,
            remaining_seconds=remaining_seconds,
            progress_percent=progress,
        )
