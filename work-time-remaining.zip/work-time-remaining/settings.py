"""
settings.py
------------
Persistent application settings management for Work Time Remaining.

Handles loading and saving user preferences (work schedule, theme,
window geometry, always-on-top flag, etc.) to a small JSON file stored
in the user's home directory. Storing it outside the project folder
means settings persist across app restarts without cluttering the
source tree or requiring write access next to the installed code.
"""

from __future__ import annotations

import datetime as dt
import json
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any

from utils import parse_time_string

# Directory & file where settings are persisted between sessions.
APP_DIR: Path = Path.home() / ".work_time_remaining"
SETTINGS_FILE: Path = APP_DIR / "settings.json"


@dataclass
class AppSettings:
    """Data container for all user-configurable application settings."""

    start_time: str = "09:00 AM"
    end_time: str = "05:00 PM"
    theme: str = "dark"  # "dark" or "light"
    always_on_top: bool = False
    window_x: int = 200
    window_y: int = 100
    window_width: int = 480
    window_height: int = 700

    def start_time_obj(self) -> dt.time:
        """Return `start_time` parsed into a `datetime.time` object."""
        return parse_time_string(self.start_time)

    def end_time_obj(self) -> dt.time:
        """Return `end_time` parsed into a `datetime.time` object."""
        return parse_time_string(self.end_time)


class SettingsManager:
    """
    Reads and writes `AppSettings` to/from disk as JSON.

    Isolating all file I/O in this class means the rest of the
    application (UI, timer) can work purely with the `AppSettings`
    dataclass and never has to know where or how it is stored.
    """

    def __init__(self, settings_path: Path = SETTINGS_FILE) -> None:
        self.settings_path = settings_path
        self.settings: AppSettings = self.load()

    def load(self) -> AppSettings:
        """
        Load settings from disk, falling back to defaults whenever
        anything goes wrong (missing file, corrupted JSON, unexpected
        types, etc.) so the app never fails to start because of a bad
        settings file.
        """
        if not self.settings_path.exists():
            return AppSettings()

        try:
            with open(self.settings_path, "r", encoding="utf-8") as file:
                raw_data: dict[str, Any] = json.load(file)
        except (OSError, json.JSONDecodeError) as error:
            print(f"[Settings] Could not read settings file ({error}); using defaults.")
            return AppSettings()

        # Only keep keys that correspond to known fields, so renamed /
        # removed settings in older files never crash the dataclass.
        known_fields = {f.name for f in fields(AppSettings)}
        filtered = {key: value for key, value in raw_data.items() if key in known_fields}

        try:
            return AppSettings(**filtered)
        except TypeError as error:
            print(f"[Settings] Settings file had invalid values ({error}); using defaults.")
            return AppSettings()

    def save(self) -> None:
        """Persist the current settings to disk, creating the directory if needed."""
        try:
            self.settings_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.settings_path, "w", encoding="utf-8") as file:
                json.dump(asdict(self.settings), file, indent=4)
        except OSError as error:
            print(f"[Settings] Could not save settings: {error}")

    def update(self, **kwargs: Any) -> None:
        """Update one or more settings fields in-place and save immediately."""
        for key, value in kwargs.items():
            if hasattr(self.settings, key):
                setattr(self.settings, key, value)
            else:
                print(f"[Settings] Ignoring unknown setting '{key}'.")
        self.save()
