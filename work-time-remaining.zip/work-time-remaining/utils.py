"""
utils.py
---------
Utility / helper functions for the Work Time Remaining application.

This module contains small, reusable, stateless helper functions used
across the application -- primarily related to time parsing, formatting,
and progress calculation. Keeping these separate from the UI and the
timer logic keeps the codebase modular and easy to test in isolation.
"""

from __future__ import annotations

import datetime as dt

# Time formats we are willing to parse from user input, tried in order.
_SUPPORTED_TIME_FORMATS: tuple[str, ...] = (
    "%I:%M %p",   # 09:00 AM
    "%I:%M%p",    # 09:00AM
    "%I %p",      # 9 AM
    "%H:%M:%S",   # 21:00:00
    "%H:%M",      # 21:00
)


def parse_time_string(time_str: str) -> dt.time:
    """
    Parse a time string into a `datetime.time` object.

    Accepts common formats such as:
        "09:00 AM", "9:00AM", "9 PM", "09:00", "21:00"

    Args:
        time_str: The raw time string to parse.

    Returns:
        A `datetime.time` object representing the parsed time.

    Raises:
        ValueError: If the string is empty or cannot be parsed in any
            of the supported formats.
    """
    cleaned = time_str.strip().upper()
    if not cleaned:
        raise ValueError("Time field cannot be empty.")

    for fmt in _SUPPORTED_TIME_FORMATS:
        try:
            return dt.datetime.strptime(cleaned, fmt).time()
        except ValueError:
            continue

    raise ValueError(
        f"Unrecognized time format: '{time_str}'. "
        "Try something like '09:00 AM' or '21:00'."
    )


def format_time_12h(time_obj: dt.time) -> str:
    """Format a `datetime.time` as a 12-hour clock string, e.g. '9:00 AM'."""
    formatted = time_obj.strftime("%I:%M %p")
    # Strip a leading zero from the hour (e.g. "09:00 AM" -> "9:00 AM").
    return formatted.lstrip("0") if not formatted.startswith("00") else formatted


def format_duration(total_seconds: float) -> str:
    """
    Format a duration given in seconds into a human-readable 'Xh YYm' string.

    The duration is rounded to the nearest whole minute (rather than
    floored) so the displayed value matches what a user would expect to
    see on a wall clock -- e.g. 6h 14m 39s reads as "6h 15m", not "6h 14m".
    Negative durations are clamped to zero to avoid nonsensical output
    (e.g. due to clock drift or rounding at the exact start/end boundary).

    Args:
        total_seconds: Duration in seconds.

    Returns:
        A formatted string such as "1h 45m" or "0h 05m".
    """
    total_seconds = max(0.0, float(total_seconds))
    total_minutes = round(total_seconds / 60)
    hours, minutes = divmod(total_minutes, 60)
    return f"{hours}h {minutes:02d}m"


def calculate_progress(now: dt.datetime, start: dt.datetime, end: dt.datetime) -> float:
    """
    Calculate the percentage of the workday completed.

    Args:
        now: The current datetime.
        start: The workday start datetime.
        end: The workday end datetime.

    Returns:
        A float between 0.0 and 100.0 representing the percent complete.
    """
    total_duration = (end - start).total_seconds()
    if total_duration <= 0:
        return 0.0

    elapsed = (now - start).total_seconds()
    percentage = (elapsed / total_duration) * 100
    return clamp(percentage, 0.0, 100.0)


def clamp(value: float, minimum: float, maximum: float) -> float:
    """Clamp `value` so it lies within [minimum, maximum]."""
    return max(minimum, min(maximum, value))
