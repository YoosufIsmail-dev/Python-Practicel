"""
ui.py
------
CustomTkinter user interface for the Work Time Remaining application.

Defines the main application window (`WorkTimeApp`) along with small
supporting classes for fonts and color palette. This module owns all
widget creation and event handling; the actual work-time math lives in
`timer.py` and persistence lives in `settings.py`, keeping this file
focused purely on presentation.
"""

from __future__ import annotations

import datetime as dt
import threading
from pathlib import Path
from tkinter import messagebox
from typing import Any, Optional

import customtkinter as ctk
from PIL import Image, ImageDraw

try:
    import pystray
except ImportError:  # pystray is optional -- tray features degrade gracefully.
    pystray = None  # type: ignore[assignment]

from settings import AppSettings, SettingsManager
from timer import WorkSnapshot, WorkStatus, WorkTimer
from utils import format_duration, format_time_12h, parse_time_string

ASSETS_DIR = Path(__file__).parent / "assets"


class Palette:
    """Centralized color palette for a clean, professional look."""

    PRIMARY = "#2563EB"          # Vibrant blue -- primary accent / in-progress
    WARNING = "#F59E0B"          # Amber -- "not started" state
    SUCCESS = "#16A34A"          # Green -- "completed" state
    CARD = ("#F1F5F9", "#1E293B")          # (light, dark) card background
    MUTED_TEXT = ("#64748B", "#94A3B8")    # (light, dark) secondary text


class Fonts:
    """Container for the CTkFont objects used throughout the UI."""

    def __init__(self) -> None:
        self.title = ctk.CTkFont(family="Segoe UI", size=22, weight="bold")
        self.subtitle = ctk.CTkFont(family="Segoe UI", size=13)
        self.clock = ctk.CTkFont(family="Segoe UI", size=40, weight="bold")
        self.date = ctk.CTkFont(family="Segoe UI", size=14)
        self.label = ctk.CTkFont(family="Segoe UI", size=12, weight="bold")
        self.stat_value = ctk.CTkFont(family="Segoe UI", size=22, weight="bold")
        self.status = ctk.CTkFont(family="Segoe UI", size=16, weight="bold")
        self.button = ctk.CTkFont(family="Segoe UI", size=13, weight="bold")


class WorkTimeApp(ctk.CTk):
    """
    Main application window for Work Time Remaining.

    Builds the full UI, wires up event handlers (schedule changes,
    theme toggle, always-on-top, system tray), and drives the
    once-per-second update loop that keeps the clock and progress
    display in sync with the configured work schedule.
    """

    def __init__(self) -> None:
        super().__init__()

        # --- Settings & business logic --------------------------------------
        self.settings_manager = SettingsManager()
        settings: AppSettings = self.settings_manager.settings

        ctk.set_appearance_mode(settings.theme)

        self.timer = WorkTimer(
            start_time=settings.start_time_obj(),
            end_time=settings.end_time_obj(),
        )

        # --- Window configuration --------------------------------------------
        self.title("Work Time Remaining")
        self.minsize(420, 600)
        self._restore_window_geometry(settings)
        self.attributes("-topmost", settings.always_on_top)
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._set_window_icon()

        self.fonts = Fonts()
        self._tray_icon: Optional[Any] = None
        self._tray_thread: Optional[threading.Thread] = None

        # --- Layout -------------------------------------------------------------
        self.grid_columnconfigure(0, weight=1)
        self._build_header()
        self._build_clock_section()
        self._build_schedule_section(settings)
        self._build_stats_section()
        self._build_progress_section()
        self._build_status_section()
        self._build_controls_section(settings)

        # Populate the "Total Hours" card and run the first tick immediately,
        # rather than leaving placeholders on screen for a full second.
        self._update_total_hours_label(settings.start_time_obj(), settings.end_time_obj())
        self._tick()

    # ------------------------------------------------------------------ #
    # Window setup helpers
    # ------------------------------------------------------------------ #

    def _restore_window_geometry(self, settings: AppSettings) -> None:
        """Apply the saved window size/position, falling back on bad values."""
        try:
            self.geometry(
                f"{settings.window_width}x{settings.window_height}"
                f"+{settings.window_x}+{settings.window_y}"
            )
        except Exception as error:  # noqa: BLE001 -- defensive UI startup guard
            print(f"[UI] Could not restore window geometry ({error}); using default.")
            self.geometry("480x700")

    def _set_window_icon(self) -> None:
        """Set the taskbar/window icon if an .ico file is available (Windows)."""
        icon_path = ASSETS_DIR / "icon.ico"
        try:
            if icon_path.exists():
                self.iconbitmap(str(icon_path))
        except Exception as error:  # noqa: BLE001 -- icon is cosmetic, never fatal
            print(f"[UI] Could not set window icon: {error}")

    # ------------------------------------------------------------------ #
    # Widget construction
    # ------------------------------------------------------------------ #

    def _build_header(self) -> None:
        """Build the top title / subtitle section."""
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=24, pady=(24, 8))
        header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            header, text="⏰ Work Time Remaining", font=self.fonts.title
        ).grid(row=0, column=0, sticky="w")

        ctk.CTkLabel(
            header,
            text="Track your workday in real time",
            font=self.fonts.subtitle,
            text_color=Palette.MUTED_TEXT,
        ).grid(row=1, column=0, sticky="w", pady=(2, 0))

    def _build_clock_section(self) -> None:
        """Build the large current-time / current-date display card."""
        card = ctk.CTkFrame(self, corner_radius=18, fg_color=Palette.CARD)
        card.grid(row=1, column=0, sticky="ew", padx=24, pady=8)
        card.grid_columnconfigure(0, weight=1)

        self.clock_label = ctk.CTkLabel(card, text="--:--:--", font=self.fonts.clock)
        self.clock_label.grid(row=0, column=0, pady=(18, 0))

        self.date_label = ctk.CTkLabel(
            card, text="", font=self.fonts.date, text_color=Palette.MUTED_TEXT
        )
        self.date_label.grid(row=1, column=0, pady=(0, 18))

    def _build_schedule_section(self, settings: AppSettings) -> None:
        """Build the work-schedule input row (start time, end time, apply button)."""
        section = ctk.CTkFrame(self, fg_color="transparent")
        section.grid(row=2, column=0, sticky="ew", padx=24, pady=8)
        section.grid_columnconfigure((0, 1), weight=1)

        ctk.CTkLabel(section, text="Start Time", font=self.fonts.label).grid(
            row=0, column=0, sticky="w"
        )
        ctk.CTkLabel(section, text="End Time", font=self.fonts.label).grid(
            row=0, column=1, sticky="w", padx=(12, 0)
        )

        self.start_entry = ctk.CTkEntry(section, corner_radius=10)
        self.start_entry.insert(0, settings.start_time)
        self.start_entry.grid(row=1, column=0, sticky="ew", pady=(4, 0))

        self.end_entry = ctk.CTkEntry(section, corner_radius=10)
        self.end_entry.insert(0, settings.end_time)
        self.end_entry.grid(row=1, column=1, sticky="ew", padx=(12, 0), pady=(4, 0))

        ctk.CTkButton(
            section,
            text="Apply Schedule",
            corner_radius=10,
            font=self.fonts.button,
            command=self._apply_schedule,
        ).grid(row=2, column=0, columnspan=2, sticky="ew", pady=(10, 0))

    def _build_stat_card(
        self, parent: ctk.CTkFrame, icon: str, title: str
    ) -> tuple[ctk.CTkFrame, ctk.CTkLabel]:
        """
        Build a small rounded "stat card" with an icon+title header and a
        large value label underneath.

        Returns:
            A tuple of (card_frame, value_label) so the caller can place
            the card in a grid and later update the value label's text.
        """
        card = ctk.CTkFrame(parent, corner_radius=14, fg_color=Palette.CARD)
        card.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            card,
            text=f"{icon}  {title}",
            font=self.fonts.label,
            text_color=Palette.MUTED_TEXT,
        ).grid(row=0, column=0, sticky="w", padx=14, pady=(12, 0))

        value_label = ctk.CTkLabel(card, text="--", font=self.fonts.stat_value)
        value_label.grid(row=1, column=0, sticky="w", padx=14, pady=(0, 12))

        return card, value_label

    def _build_stats_section(self) -> None:
        """Build the row of stat cards: Worked, Remaining, Total Hours."""
        section = ctk.CTkFrame(self, fg_color="transparent")
        section.grid(row=3, column=0, sticky="ew", padx=24, pady=8)
        section.grid_columnconfigure((0, 1, 2), weight=1)

        worked_card, self.worked_value = self._build_stat_card(section, "💪", "Worked")
        worked_card.grid(row=0, column=0, sticky="ew", padx=(0, 6))

        remaining_card, self.remaining_value = self._build_stat_card(
            section, "⏳", "Remaining"
        )
        remaining_card.grid(row=0, column=1, sticky="ew", padx=6)

        total_card, self.total_hours_value = self._build_stat_card(
            section, "📅", "Total Hours"
        )
        total_card.grid(row=0, column=2, sticky="ew", padx=(6, 0))

    def _build_progress_section(self) -> None:
        """Build the animated progress bar and its percentage label."""
        section = ctk.CTkFrame(self, fg_color="transparent")
        section.grid(row=4, column=0, sticky="ew", padx=24, pady=(12, 8))
        section.grid_columnconfigure(0, weight=1)

        header_row = ctk.CTkFrame(section, fg_color="transparent")
        header_row.grid(row=0, column=0, sticky="ew")
        header_row.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(header_row, text="Progress", font=self.fonts.label).grid(
            row=0, column=0, sticky="w"
        )
        self.progress_percent_label = ctk.CTkLabel(
            header_row, text="0%", font=self.fonts.label
        )
        self.progress_percent_label.grid(row=0, column=1, sticky="e")

        self.progress_bar = ctk.CTkProgressBar(section, corner_radius=10, height=18)
        self.progress_bar.set(0)
        self.progress_bar.grid(row=1, column=0, sticky="ew", pady=(6, 0))

    def _build_status_section(self) -> None:
        """Build the friendly status message label below the progress bar."""
        self.status_label = ctk.CTkLabel(self, text="", font=self.fonts.status)
        self.status_label.grid(row=5, column=0, pady=(8, 8))

    def _build_controls_section(self, settings: AppSettings) -> None:
        """Build the bottom controls: theme switch, always-on-top, tray button."""
        section = ctk.CTkFrame(self, fg_color="transparent")
        section.grid(row=6, column=0, sticky="ew", padx=24, pady=(8, 20))
        section.grid_columnconfigure((0, 1), weight=1)

        self.theme_switch = ctk.CTkSwitch(
            section, text="Dark Mode", command=self._toggle_theme
        )
        if settings.theme == "dark":
            self.theme_switch.select()
        else:
            self.theme_switch.deselect()
        self.theme_switch.grid(row=0, column=0, sticky="w")

        self.always_on_top_switch = ctk.CTkSwitch(
            section, text="Always on Top", command=self._toggle_always_on_top
        )
        if settings.always_on_top:
            self.always_on_top_switch.select()
        self.always_on_top_switch.grid(row=0, column=1, sticky="e")

        ctk.CTkButton(
            section,
            text="🗂️  Minimize to Tray",
            corner_radius=10,
            font=self.fonts.button,
            fg_color="transparent",
            border_width=1,
            command=self._minimize_to_tray,
        ).grid(row=1, column=0, columnspan=2, sticky="ew", pady=(10, 0))

    # ------------------------------------------------------------------ #
    # Live update loop
    # ------------------------------------------------------------------ #

    def _tick(self) -> None:
        """Refresh all live widgets, then reschedule itself for one second later."""
        try:
            snapshot = self.timer.snapshot()
            self._render_snapshot(snapshot)
        except Exception as error:  # noqa: BLE001 -- never let the loop die silently
            print(f"[UI] Error during update tick: {error}")
        finally:
            self.after(1000, self._tick)

    def _render_snapshot(self, snapshot: WorkSnapshot) -> None:
        """Push a `WorkSnapshot`'s computed values into the relevant widgets."""
        self.clock_label.configure(text=self._format_clock(snapshot.now))
        self.date_label.configure(text=snapshot.now.strftime("%A, %B %d, %Y"))

        self.worked_value.configure(text=snapshot.worked_label)
        self.remaining_value.configure(text=snapshot.remaining_label)

        self.progress_bar.set(snapshot.progress_percent / 100)
        self.progress_percent_label.configure(text=snapshot.progress_label)

        self.status_label.configure(
            text=snapshot.status_message,
            text_color=self._status_color(snapshot.status),
        )

    @staticmethod
    def _format_clock(moment: dt.datetime) -> str:
        """Format a datetime as a 12-hour clock string, e.g. '10:45:21 AM'."""
        text = moment.strftime("%I:%M:%S %p")
        return text.lstrip("0") if not text.startswith("00") else text

    @staticmethod
    def _status_color(status: WorkStatus) -> str:
        """Return an appropriate text color for the given work status."""
        if status is WorkStatus.NOT_STARTED:
            return Palette.WARNING
        if status is WorkStatus.COMPLETED:
            return Palette.SUCCESS
        return Palette.PRIMARY

    def _update_total_hours_label(self, start_time: dt.time, end_time: dt.time) -> None:
        """Recompute and display the total scheduled working hours for the day."""
        start_dt = dt.datetime.combine(dt.date.today(), start_time)
        end_dt = dt.datetime.combine(dt.date.today(), end_time)
        if end_dt <= start_dt:
            end_dt += dt.timedelta(days=1)
        total_seconds = (end_dt - start_dt).total_seconds()
        self.total_hours_value.configure(text=format_duration(total_seconds))

    # ------------------------------------------------------------------ #
    # Event handlers
    # ------------------------------------------------------------------ #

    def _apply_schedule(self) -> None:
        """Validate and apply the work start/end time entered by the user."""
        start_str = self.start_entry.get()
        end_str = self.end_entry.get()

        try:
            start_time = parse_time_string(start_str)
            end_time = parse_time_string(end_str)
        except ValueError as error:
            messagebox.showerror("Invalid Time", f"Please enter a valid time.\n\n{error}")
            return

        self.timer.set_schedule(start_time, end_time)
        self.settings_manager.update(
            start_time=format_time_12h(start_time),
            end_time=format_time_12h(end_time),
        )
        self._update_total_hours_label(start_time, end_time)
        self._tick()  # Refresh immediately rather than waiting for the next second.

    def _toggle_theme(self) -> None:
        """Switch between light and dark appearance modes."""
        is_dark = bool(self.theme_switch.get())
        mode = "dark" if is_dark else "light"
        ctk.set_appearance_mode(mode)
        self.settings_manager.update(theme=mode)

    def _toggle_always_on_top(self) -> None:
        """Toggle whether the window stays above all other windows."""
        is_on_top = bool(self.always_on_top_switch.get())
        self.attributes("-topmost", is_on_top)
        self.settings_manager.update(always_on_top=is_on_top)

    # ------------------------------------------------------------------ #
    # System tray support (optional -- requires `pystray`)
    # ------------------------------------------------------------------ #

    def _minimize_to_tray(self) -> None:
        """Hide the main window and show a system tray icon in its place."""
        if pystray is None:
            messagebox.showwarning(
                "Tray Unavailable",
                "System tray support requires the 'pystray' package.\n"
                "Install it with: pip install pystray",
            )
            return

        self.withdraw()
        self._ensure_tray_icon()

    def _ensure_tray_icon(self) -> None:
        """Create and start the tray icon thread if it isn't already running."""
        if self._tray_icon is not None:
            return

        image = self._load_tray_image()
        menu = pystray.Menu(
            pystray.MenuItem("Show", self._restore_from_tray, default=True),
            pystray.MenuItem("Quit", self._quit_from_tray),
        )
        self._tray_icon = pystray.Icon("work_time_remaining", image, "Work Time Remaining", menu)

        # pystray's `run()` blocks, so it must live on its own daemon thread.
        self._tray_thread = threading.Thread(target=self._tray_icon.run, daemon=True)
        self._tray_thread.start()

    def _restore_from_tray(self, icon: Any, item: Any) -> None:
        """Tray callback: stop the tray icon and bring the window back."""
        icon.stop()
        self._tray_icon = None
        # Tray callbacks run on pystray's own thread -- hop back onto the
        # Tkinter main thread before touching any widgets.
        self.after(0, self.deiconify)

    def _quit_from_tray(self, icon: Any, item: Any) -> None:
        """Tray callback: fully quit the application from the tray menu."""
        icon.stop()
        self._tray_icon = None
        self.after(0, self._on_close)

    def _load_tray_image(self) -> Image.Image:
        """Load the app's .ico file for the tray icon, or generate a fallback."""
        icon_path = ASSETS_DIR / "icon.ico"
        try:
            if icon_path.exists():
                return Image.open(icon_path)
        except Exception as error:  # noqa: BLE001 -- fall back to a generated icon
            print(f"[Tray] Could not load icon file ({error}); generating a placeholder.")
        return self._generate_placeholder_icon()

    @staticmethod
    def _generate_placeholder_icon() -> Image.Image:
        """Generate a simple clock-style icon in memory as a tray-icon fallback."""
        size = 64
        image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        draw.ellipse((2, 2, size - 2, size - 2), fill=Palette.PRIMARY)
        draw.line((size // 2, size // 2, size // 2, 14), fill="white", width=4)
        draw.line((size // 2, size // 2, size - 18, size // 2), fill="white", width=4)
        return image

    # ------------------------------------------------------------------ #
    # Shutdown
    # ------------------------------------------------------------------ #

    def _on_close(self) -> None:
        """Persist window geometry and gracefully shut down before exiting."""
        try:
            self.settings_manager.update(
                window_x=self.winfo_x(),
                window_y=self.winfo_y(),
                window_width=self.winfo_width(),
                window_height=self.winfo_height(),
            )
        except Exception as error:  # noqa: BLE001 -- never block shutdown on this
            print(f"[UI] Could not save window geometry: {error}")

        if self._tray_icon is not None:
            try:
                self._tray_icon.stop()
            except Exception as error:  # noqa: BLE001
                print(f"[Tray] Error stopping tray icon: {error}")

        self.destroy()
