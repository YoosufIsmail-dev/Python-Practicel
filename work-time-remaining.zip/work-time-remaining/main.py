"""
main.py
--------
Entry point for the Work Time Remaining desktop application.

Run this file to launch the app:

    python main.py
"""

from __future__ import annotations

import sys

import customtkinter as ctk

from ui import WorkTimeApp


def main() -> None:
    """Configure global CustomTkinter defaults and launch the application."""
    ctk.set_default_color_theme("blue")

    try:
        app = WorkTimeApp()
        app.mainloop()
    except Exception as error:  # noqa: BLE001 -- top-level safety net
        print(f"[Fatal] Work Time Remaining crashed: {error}")
        sys.exit(1)


if __name__ == "__main__":
    main()
