# Work Time Remaining ⏰

A modern, professional desktop application built with **Python** and
**CustomTkinter** that tracks your workday in real time — showing how much
time you've worked, how much remains, and your overall progress as a clean,
animated progress bar.

## Features

- 🕒 Live current time & date display, updating every second
- 🛠️ Configurable work start/end time (defaults to **09:00 AM – 05:00 PM**)
- 📊 At-a-glance stats: time worked, time remaining, total scheduled hours
- 📈 Smooth animated progress bar with a live percentage-completed label
- 🟡 "Work has not started" message before your shift begins
- 🎉 "Work Completed!" message once your shift ends
- 🌗 Light / Dark mode toggle
- 📌 Always-on-top window option
- 🗂️ Minimize to system tray (optional — requires `pystray`)
- 💾 Remembers your window position/size, theme, and schedule between sessions
- 🌙 Supports overnight shifts (e.g. 09:00 PM → 05:00 AM)
- 🎨 Clean, rounded, modern UI with a professional color palette

## Project Structure

```
work-time-remaining/
│
├── main.py            # Application entry point
├── ui.py              # CustomTkinter UI: window, widgets, event handlers
├── timer.py           # Pure work-time calculation logic (no UI dependencies)
├── settings.py        # Persistent settings load/save (JSON in user home dir)
├── utils.py           # Small stateless helpers (time parsing/formatting)
├── assets/
│   └── icon.ico        # App / tray icon
├── requirements.txt
└── README.md
```

## Installation

1. Make sure you have **Python 3.12+** installed.
2. Open a terminal in the project folder.
3. *(Recommended)* create and activate a virtual environment:

   ```bash
   python -m venv venv
   source venv/bin/activate      # On Windows: venv\Scripts\activate
   ```

4. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

## Running

```bash
python main.py
```

The app opens with the default **09:00 AM – 05:00 PM** schedule already
running. To set your own hours, edit the **Start Time** / **End Time**
fields (accepts formats like `9:00 AM` or `21:00`) and click **Apply
Schedule** — your choice is saved automatically and restored next time you
open the app.

## Screenshots

> _Add screenshots of the running app here once captured, for example:_
>
> | Light Mode | Dark Mode |
> |---|---|
> | `screenshots/light.png` | `screenshots/dark.png` |

## Notes

- Settings (schedule, theme, window position/size, always-on-top) are
  stored in `~/.work_time_remaining/settings.json` and persist across
  restarts.
- System tray support is optional. If `pystray` isn't installed, clicking
  **Minimize to Tray** shows a friendly warning instead of crashing the app.
- All core time/progress calculations live in `timer.py` and are completely
  independent of the UI, so they're easy to unit test on their own.

## License

This project is released under the **MIT License** — free to use, modify,
and distribute.
